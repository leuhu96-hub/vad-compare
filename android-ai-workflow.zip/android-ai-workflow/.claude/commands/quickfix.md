---
description: Sửa nhanh bug/task nhỏ — bỏ Plan & Design, chỉ Implement → Test → Review
argument-hint: <mô tả bug hoặc task nhỏ>
---
Task: $ARGUMENTS

1. Tìm đúng chỗ cần sửa bằng Grep/Glob (không đọc cả thư mục). Sửa tối thiểu.
2. Build bằng lệnh trong CLAUDE.md đến khi pass.
3. Nếu thay đổi có logic test được: gọi subagent `tester`. Nếu chỉ đổi text/config: bỏ qua.
4. Nếu có sửa JNI hoặc C++: chạy `bash scripts/ai/review.sh` và xử lý CRITICAL/MAJOR. Java thuần: bỏ qua review.
5. Báo cáo tối đa 4 dòng + đề xuất commit message.
