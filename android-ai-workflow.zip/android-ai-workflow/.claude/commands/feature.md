---
description: Quy trình đầy đủ Plan → Design → Implement → Test → Review cho 1 tính năng
argument-hint: <mô tả tính năng>
---
Tính năng: $ARGUMENTS

Thực hiện ĐÚNG thứ tự, output giữa các bước ngắn nhất có thể:

1. **Plan (Gemini)**: chạy `bash scripts/ai/plan.sh "$ARGUMENTS"`. Đọc docs/ai/plan.md.
2. **Design (subagent architect)**: gọi subagent `architect`.
3. **DỪNG**: tóm tắt plan + design trong tối đa 8 dòng, hỏi tôi duyệt. Chỉ đi tiếp khi tôi đồng ý.
4. **Implement (bạn)**: code theo docs/ai/design.md. Chỉ sửa file trong design. Build bằng lệnh trong CLAUDE.md đến khi pass.
5. **Test (subagent tester)**: gọi subagent `tester`. Nếu có FAIL do code chính, sửa code rồi gọi lại tester (tối đa 2 lần).
6. **Review (Codex)**: chạy `bash scripts/ai/review.sh`. Sửa các mục CRITICAL/MAJOR, bỏ qua MINOR trừ khi sửa mất dưới 1 phút.
   Nếu VERDICT: FIX_NEEDED, sửa rồi chạy lại review — tối đa 2 vòng.
7. **Kết thúc**: báo cáo tối đa 6 dòng: file đã sửa, kết quả test, verdict review, việc còn lại.
   Đề xuất commit message (không tự commit).
