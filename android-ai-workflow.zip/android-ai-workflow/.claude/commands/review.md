---
description: Chỉ chạy review bằng Codex cho thay đổi hiện tại (hoặc so với 1 nhánh)
argument-hint: [nhánh gốc, mặc định HEAD]
---
Chạy `bash scripts/ai/review.sh $ARGUMENTS`.
Liệt kê lại các mục CRITICAL/MAJOR (mỗi mục 1 dòng) và hỏi tôi có muốn sửa không. Không tự sửa.
