# Bộ workflow AI cho Android Java + NDK

Claude Code điều phối, Gemini lập kế hoạch, Codex review.

## Phân vai & model

| Khâu | Ai làm | Model | File |
|---|---|---|---|
| Plan | Gemini CLI | mặc định CLI (đổi bằng `GEMINI_MODEL`) | `scripts/ai/plan.sh`, `GEMINI.md` |
| Design | Claude subagent `architect` | sonnet | `.claude/agents/architect.md` |
| Implement | Claude Code (session chính) | sonnet | `.claude/settings.json` |
| Test | Claude subagent `tester` | haiku | `.claude/agents/tester.md` |
| Review | Codex CLI | mặc định CLI, effort low (đổi bằng `CODEX_MODEL`, `CODEX_EFFORT`) | `scripts/ai/review.sh`, `AGENTS.md` |

## Cài đặt (1 lần)

1. Copy toàn bộ nội dung thư mục này vào gốc project Android (cùng cấp `settings.gradle`).
2. `chmod +x scripts/ai/*.sh`
3. Kiểm tra 3 CLI đã đăng nhập: `claude`, `gemini`, `codex`.
4. Sửa phần **Lệnh** trong `CLAUDE.md` cho đúng project (tên module, target gtest...).
5. (Tuỳ chọn) đặt model rẻ cho Gemini/Codex trong `~/.bashrc`:
   ```bash
   export GEMINI_MODEL=<model flash hiện có>
   export CODEX_MODEL=<model nhỏ hiện có>
   ```
   Xem tên model hiện có bằng `/model` trong từng CLI.

## Sử dụng

Mở `claude` ở gốc project rồi gõ:

- `/feature thêm noise gate vào audio pipeline` — quy trình đầy đủ, dừng ở bước 3 cho bạn duyệt design
- `/quickfix crash khi release AudioEngine lúc đang play` — task nhỏ, bỏ plan/design
- `/review` hoặc `/review main` — chỉ review

Có thể chạy riêng script ngoài Claude: `bash scripts/ai/review.sh main`.

## Vì sao tiết kiệm token

- Đọc codebase (khâu tốn nhất) chạy trên quota Gemini.
- Output Gemini/Codex ghi ra file; Claude chỉ đọc file ngắn hoặc dòng kết luận.
- Codex chỉ nhận diff, ở chế độ read-only, effort low.
- Tester dùng haiku và chỉ trả về tối đa 15 dòng.
- Mọi file output có giới hạn số dòng.
- `settings.json` chặn đọc thư mục build/.cxx/.gradle.
- `/quickfix` bỏ hẳn plan/design cho việc nhỏ.

Thói quen nên giữ: gõ `/clear` sau mỗi tính năng; chỉ chuyển `/model opus` khi gặp lỗi JNI/threading thật sự khó rồi chuyển lại sonnet.
