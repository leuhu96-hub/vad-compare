# Project rules (giữ file này NGẮN — nạp vào mọi lần gọi)

## Stack
- Android app: Java (không Kotlin), minSdk/targetSdk theo app/build.gradle
- Native: C++17, CMake, NDK — code ở app/src/main/cpp, JNI glue ở app/src/main/cpp/jni/
- Audio: callback real-time → KHÔNG malloc/new, lock, log, JNI call trong callback

## Lệnh
- Build:        ./gradlew assembleDebug -q
- Unit test:    ./gradlew testDebugUnitTest -q 2>&1 | tail -60
- Native test:  ./gradlew :app:externalNativeBuildDebug -q && (chạy gtest nếu có target native_tests)
- Lint:         ./gradlew lintDebug -q 2>&1 | tail -40

## Quy ước JNI
- Mỗi JNI call kiểm tra ExceptionCheck; DeleteLocalRef trong vòng lặp
- GlobalRef phải có chỗ giải phóng rõ ràng; thread native phải Attach/Detach
- Con trỏ native giữ trong `long mNativeHandle`, có `release()` phía Java

## Quy trình
- Tài liệu workflow ở docs/ai/ (plan.md, design.md, review.md) — đọc file, không hỏi lại
- Output ngắn gọn. Không lặp lại code đã có. Không giải thích điều hiển nhiên.
- Chỉ sửa file liên quan task. Không refactor ngoài phạm vi.
