#!/usr/bin/env bash
# Khâu PLAN — gọi Gemini (đọc codebase bằng quota Gemini, không tốn token Claude)
# Dùng: scripts/ai/plan.sh "mô tả tính năng"
# Đổi model: GEMINI_MODEL=<tên-model> scripts/ai/plan.sh "..."
set -euo pipefail

TASK="${1:?Cần mô tả tính năng}"
OUT="docs/ai/plan.md"
mkdir -p docs/ai

MODEL_ARGS=()
if [[ -n "${GEMINI_MODEL:-}" ]]; then MODEL_ARGS=(-m "$GEMINI_MODEL"); fi

gemini "${MODEL_ARGS[@]}" -p "Theo GEMINI.md, lập kế hoạch cho tính năng sau. Chỉ in kế hoạch, không gì khác.
Tính năng: $TASK
Codebase chính: @app/src/main/java @app/src/main/cpp @app/build.gradle" > "$OUT"

echo "PLAN -> $OUT ($(wc -l < "$OUT") dòng)"
