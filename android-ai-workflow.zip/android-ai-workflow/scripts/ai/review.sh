#!/usr/bin/env bash
# Khâu REVIEW — gọi Codex, CHỈ đưa diff (không đưa cả repo) để tiết kiệm token
# Dùng: scripts/ai/review.sh            (review thay đổi chưa commit)
#       scripts/ai/review.sh main       (review so với nhánh main)
# Đổi model/effort: CODEX_MODEL=<tên> CODEX_EFFORT=medium scripts/ai/review.sh
set -euo pipefail

BASE="${1:-HEAD}"
EFFORT="${CODEX_EFFORT:-low}"
DIFF="docs/ai/diff.patch"
OUT="docs/ai/review.md"
mkdir -p docs/ai

# Bỏ file build/generated khỏi diff
git diff "$BASE" -- . ':!*.lock' ':!**/build/**' ':!**/.cxx/**' > "$DIFF"
if [[ ! -s "$DIFF" ]]; then echo "Không có thay đổi để review."; exit 0; fi

MODEL_ARGS=()
if [[ -n "${CODEX_MODEL:-}" ]]; then MODEL_ARGS=(-m "$CODEX_MODEL"); fi

codex exec "${MODEL_ARGS[@]}" -s read-only -c model_reasoning_effort="$EFFORT" \
  "Theo AGENTS.md, review file $DIFF (đối chiếu docs/ai/design.md nếu có). Chỉ mở thêm file nguồn khi cần ngữ cảnh quanh dòng bị sửa." \
  > "$OUT"

# Chỉ in dòng kết luận ra cho Claude đọc, tránh nạp cả output
grep -E '^\[(CRITICAL|MAJOR)\]|VERDICT' "$OUT" || tail -5 "$OUT"
echo "REVIEW -> $OUT"
